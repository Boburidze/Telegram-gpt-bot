# Telegram GPT Bot
Бот для Telegram с поддержкой ChatGPT (OpenAI API).

## Переменные среды:
- `BOT_TOKEN` — токен Telegram-бота
- `OPENAI_API_KEY` — API-ключ OpenAI